/*
 * 
♥♥♥♥♥♥♥♥♥
Executes Commands to the OS and the Simulators
♥♥♥♥♥♥♥♥♥


 */
package pkg312project;

/**
 *
 * @author Najia13
 */
public class CommandInterface {
    
    
    public void proc(){}
    public void mem(){}
    public void exe(){}
    public void reset(){}
    public void promptUser(){}
    
    
}
