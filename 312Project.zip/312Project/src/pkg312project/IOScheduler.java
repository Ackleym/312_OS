/*
 * ♥♥♥♥ Simulates I/O devices ♥♥♥♥♥
 */
package pkg312project;





public class IOScheduler {
    public void scheduleIO(){}
    public void startIO(){}
    
    
    
}
