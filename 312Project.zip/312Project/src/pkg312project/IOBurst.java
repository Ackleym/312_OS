/*
 *♥♥♥♥ Randomly determines IO burst times ♥♥♥♥♥
 */
package pkg312project;

/**
 *
 * @author Najia13
 */
public class IOBurst {
    public void generateIOBurst(){}
    
}
