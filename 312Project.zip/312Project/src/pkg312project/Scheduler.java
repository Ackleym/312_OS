/*
 *♥♥♥♥♥♥♥♥♥
Schedules processes according to round robin Algorithm with a time quantum of 10 cycles
♥♥♥♥♥♥♥♥♥
 */
package pkg312project;

/**
 *
 * @author Najia13
 */
public class Scheduler {
    
    public void insertPCB(){}
    public void removePCB(){}
    public void getState(){}
    public void setState(){}
    public void getWait(){}
    public void setWait(){}
    public void getArrival(){}
    public void setArrival(){}
    public void getCPUTime(){}
    public void setCPUTime(){}
    
    
}
