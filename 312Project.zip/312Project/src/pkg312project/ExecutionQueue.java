/*
 * ♥♥♥♥♥♥♥♥♥
Encapsulates the queue structure used by Scheduler
♥♥♥♥♥♥♥♥♥
 */
package pkg312project;

/**
 *
 * @author Najia13
 */
public class ExecutionQueue {
    
    public void enQueue(){}
    public void deQueue(){}
    
    
    
    
}
